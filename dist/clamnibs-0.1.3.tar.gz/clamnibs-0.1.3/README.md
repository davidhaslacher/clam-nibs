<p align="center"><img src="https://github.com/davidhaslacher/clam-nibs/assets/17557712/42767758-25fd-43ce-952e-53eda9240273" width="200"></p>
This toolbox contains all software required to implement closed-loop amplitude-modulated non-invasive brain stimulation (CLAM-NIBS) and evaluate the resulting electroencephalography (EEG) or magnetoencephalography (MEG) data.
